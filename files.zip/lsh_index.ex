defmodule RinhaFraud.LSHIndex do
  @moduledoc """
  Locality-Sensitive Hashing index para busca aproximada de vizinhos próximos
  usando distância euclidiana (E2LSH com random projections).

  Parâmetros de configuração:
    - L: número de tabelas hash (mais tabelas = mais recall, mais memória)
    - K: número de funções por tabela (mais funções = buckets mais precisos, menos candidatos)
    - W: largura do bucket (maior W = mais candidatos por bucket)

  Para 100k vetores de 14 dims, os defaults (L=8, K=4, W=4.0) oferecem
  ~95% de recall com ~2-5% dos vetores como candidatos por query.

  Estrutura ETS:
    - :lsh_projections  → {table_idx, projection_matrix, offsets}
    - :lsh_buckets      → {{table_idx, bucket_key}, [entry_id, ...]}
    - :lsh_entries      → {entry_id, vector, label}  (:fraud | :legit)
  """

  use GenServer
  require Logger

  @dims 14
  # Hiperparâmetros — ajuste conforme benchmark
  @l 8      # número de tabelas hash
  @k 4      # funções hash por tabela (banda)
  @w 4.0    # largura do bucket

  # -------------------------
  # API pública
  # -------------------------

  def start_link(opts \\ []) do
    GenServer.start_link(__MODULE__, opts, name: __MODULE__)
  end

  @doc "Busca os k vizinhos mais próximos. Retorna [{dist, label}, ...]"
  def knn(query_vec, k \\ 5) do
    GenServer.call(__MODULE__, {:knn, query_vec, k})
  end

  @doc "Retorna quantas entradas estão indexadas"
  def size do
    :ets.info(:lsh_entries, :size)
  end

  # -------------------------
  # GenServer callbacks
  # -------------------------

  @impl true
  def init(_opts) do
    :ets.new(:lsh_projections, [:named_table, :public, read_concurrency: true])
    :ets.new(:lsh_buckets,     [:named_table, :public, read_concurrency: true, :bag])
    :ets.new(:lsh_entries,     [:named_table, :public, read_concurrency: true])

    projections = generate_projections(@l, @k, @dims)
    store_projections(projections)

    Logger.info("[LSHIndex] Tabelas ETS criadas, projeções geradas (L=#{@l}, K=#{@k}, W=#{@w})")

    {:ok, %{projections: projections, indexed: 0}}
  end

  @impl true
  def handle_call({:knn, query_vec, k}, _from, state) do
    result = do_knn(query_vec, k, state.projections)
    {:reply, result, state}
  end

  @impl true
  def handle_cast({:index_batch, entries}, state) do
    count = index_entries(entries, state.projections)
    {:noreply, %{state | indexed: state.indexed + count}}
  end

  # -------------------------
  # Indexação (chamada no startup da Application)
  # -------------------------

  @doc """
  Indexa uma lista de entradas de forma assíncrona (cast).
  Cada entrada: %{id: string, vector: [float x 14], label: :fraud | :legit}
  """
  def index_async(entries) do
    GenServer.cast(__MODULE__, {:index_batch, entries})
  end

  @doc """
  Indexa de forma síncrona — use no startup para garantir que o índice
  está pronto antes de aceitar requests.
  """
  def index_sync(entries) do
    projections = load_projections()
    count = index_entries(entries, projections)
    Logger.info("[LSHIndex] #{count} entradas indexadas")
    :ok
  end

  # -------------------------
  # Lógica de hash LSH
  # -------------------------

  # Gera L tabelas, cada uma com K pares {a, b}
  # a: vetor gaussiano de @dims dimensões
  # b: offset uniforme em [0, W)
  defp generate_projections(l, k, dims) do
    for _table <- 1..l do
      for _func <- 1..k do
        a = for _ <- 1..dims, do: :rand.normal()
        b = :rand.uniform() * @w
        {a, b}
      end
    end
  end

  defp store_projections(projections) do
    projections
    |> Enum.with_index()
    |> Enum.each(fn {table_funcs, table_idx} ->
      :ets.insert(:lsh_projections, {table_idx, table_funcs})
    end)
  end

  defp load_projections do
    for table_idx <- 0..(@l - 1) do
      [{^table_idx, funcs}] = :ets.lookup(:lsh_projections, table_idx)
      funcs
    end
  end

  # Calcula o hash de um vetor para uma tabela específica
  # Retorna uma tupla de K inteiros (a "chave" do bucket)
  defp hash_vector(vec, table_funcs) do
    table_funcs
    |> Enum.map(fn {a, b} ->
      dot = dot_product(a, vec)
      floor((dot + b) / @w)
    end)
    |> List.to_tuple()
  end

  defp dot_product(a, b) do
    Enum.zip(a, b)
    |> Enum.reduce(0.0, fn {x, y}, acc -> acc + x * y end)
  end

  # -------------------------
  # Indexação de entradas
  # -------------------------

  defp index_entries(entries, projections) do
    entries
    |> Enum.each(fn %{id: id, vector: vec, label: label} ->
      # Armazena a entrada original
      :ets.insert(:lsh_entries, {id, vec, label})

      # Insere o id em todos os buckets correspondentes
      projections
      |> Enum.with_index()
      |> Enum.each(fn {table_funcs, table_idx} ->
        bucket_key = hash_vector(vec, table_funcs)
        :ets.insert(:lsh_buckets, {{table_idx, bucket_key}, id})
      end)
    end)

    length(entries)
  end

  # -------------------------
  # Busca KNN
  # -------------------------

  defp do_knn(query_vec, k, projections) do
    # 1. Coleta candidatos de todos os buckets que o query cai
    candidate_ids =
      projections
      |> Enum.with_index()
      |> Enum.flat_map(fn {table_funcs, table_idx} ->
        bucket_key = hash_vector(query_vec, table_funcs)
        :ets.lookup(:lsh_buckets, {table_idx, bucket_key})
        |> Enum.map(fn {_key, id} -> id end)
      end)
      |> MapSet.new()  # deduplica

    # 2. Se poucos candidatos, amplia com busca exaustiva parcial
    # (fallback de segurança para queries em regiões esparsas)
    candidates =
      if MapSet.size(candidate_ids) < k * 3 do
        Logger.debug("[LSHIndex] Poucos candidatos (#{MapSet.size(candidate_ids)}), usando fallback")
        # Pega uma amostra aleatória de 500 entradas como candidatos extras
        extra = sample_entries(500)
        MapSet.union(candidate_ids, MapSet.new(extra))
      else
        candidate_ids
      end

    # 3. KNN exato nos candidatos
    candidates
    |> Enum.map(fn id ->
      case :ets.lookup(:lsh_entries, id) do
        [{^id, vec, label}] ->
          dist = euclidean_distance(query_vec, vec)
          {dist, label}
        [] ->
          nil
      end
    end)
    |> Enum.reject(&is_nil/1)
    |> Enum.sort_by(&elem(&1, 0))
    |> Enum.take(k)
  end

  defp euclidean_distance(v1, v2) do
    Enum.zip(v1, v2)
    |> Enum.reduce(0.0, fn {a, b}, acc -> acc + (a - b) * (a - b) end)
    |> :math.sqrt()
  end

  defp sample_entries(n) do
    total = :ets.info(:lsh_entries, :size)
    if total <= n do
      :ets.select(:lsh_entries, [{{:"$1", :_, :_}, [], [:"$1"]}])
    else
      # Amostragem por first_key traversal (eficiente no ETS)
      Stream.iterate(:ets.first(:lsh_entries), fn key ->
        case :ets.next(:lsh_entries, key) do
          :"$end_of_table" -> :ets.first(:lsh_entries)
          next -> next
        end
      end)
      |> Stream.take(n)
      |> Enum.to_list()
    end
  end
end
