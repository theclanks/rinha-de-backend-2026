## ============================================================
## mix.exs
## ============================================================
defmodule RinhaFraud.MixProject do
  use Mix.Project

  def project do
    [
      app: :rinha_fraud,
      version: "0.1.0",
      elixir: "~> 1.16",
      start_permanent: Mix.env() == :prod,
      deps: deps()
    ]
  end

  def application do
    [
      extra_applications: [:logger, :crypto],
      mod: {RinhaFraud.Application, []}
    ]
  end

  defp deps do
    [
      {:bandit, "~> 1.5"},
      {:plug, "~> 1.16"},
      {:jason, "~> 1.4"}
      # zero outras dependências — sem Ecto, sem Phoenix, sem FAISS
    ]
  end
end

## ============================================================
## Dockerfile
## ============================================================
# syntax=docker/dockerfile:1
FROM elixir:1.16-alpine AS builder

WORKDIR /app
RUN apk add --no-cache build-base git

COPY mix.exs mix.lock ./
RUN mix local.hex --force && mix local.rebar --force
RUN MIX_ENV=prod mix deps.get --only prod
RUN MIX_ENV=prod mix deps.compile

COPY lib ./lib
COPY config ./config

RUN MIX_ENV=prod mix release --overwrite

# ---- runtime stage ----
FROM elixir:1.16-alpine AS runtime

WORKDIR /app

# Copia os arquivos de referência (pré-baixados no build context)
COPY resources ./resources

# Copia o release compilado
COPY --from=builder /app/_build/prod/rel/rinha_fraud ./

ENV MIX_ENV=prod
ENV RELEASE_COOKIE=rinha_secret

CMD ["./bin/rinha_fraud", "start"]

## ============================================================
## docker-compose.yml
## ============================================================
version: "3.9"

services:

  nginx:
    image: nginx:1.25-alpine
    ports:
      - "9999:9999"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
    depends_on:
      - api1
      - api2
    deploy:
      resources:
        limits:
          cpus: "0.10"
          memory: "20MB"

  api1:
    &api
    image: ${DOCKER_IMAGE:-seu-usuario/rinha-fraud:latest}
    environment:
      - RELEASE_NODE=api1@rinha
      - PORT=9999
    deploy:
      resources:
        limits:
          cpus: "0.42"
          memory: "160MB"

  api2:
    <<: *api
    environment:
      - RELEASE_NODE=api2@rinha
      - PORT=9999

# Total: 0.94 CPU, ~340MB — dentro dos limites (1 CPU / 350MB)

## ============================================================
## nginx.conf
## ============================================================
# worker_processes 1;
# events { worker_connections 1024; }
#
# http {
#   upstream api {
#     server api1:9999;
#     server api2:9999;
#     # round-robin por default
#   }
#
#   server {
#     listen 9999;
#
#     location / {
#       proxy_pass http://api;
#       proxy_http_version 1.1;
#       proxy_set_header Connection "";  # keepalive
#     }
#   }
# }

## ============================================================
## config/runtime.exs
## ============================================================
# import Config
#
# # Ajusta schedulers para o container ter melhor throughput
# # (1 CPU dividida entre 2 instâncias = ~0.42 CPU cada)
# config :rinha_fraud,
#   schedulers: 2
#
# # Bandit: aceita muitas conexões concorrentes
# config :bandit,
#   thousand_island_options: [
#     num_acceptors: 50,
#     read_timeout: 5_000
#   ]
