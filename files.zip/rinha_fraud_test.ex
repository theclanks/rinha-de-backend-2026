defmodule RinhaFraud.VectorizerTest do
  use ExUnit.Case, async: true

  @consts %{
    "max_amount"              => 10_000,
    "max_installments"        => 12,
    "amount_vs_avg_ratio"     => 10,
    "max_minutes"             => 1_440,
    "max_km"                  => 1_000,
    "max_tx_count_24h"        => 20,
    "max_merchant_avg_amount" => 10_000
  }

  @mcc_risk %{
    "5411" => 0.15,   # grocery
    "7802" => 0.75    # exemplo de alto risco
  }

  # Exemplo LEGÍTIMO do DETECTION_RULES.md
  # Vetor esperado: [0.0041, 0.1667, 0.05, 0.7826, 0.3333, -1, -1, 0.0292, 0.15, 0, 1, 0, 0.15, 0.006]
  @legit_payload %{
    "id" => "tx-1329056812",
    "transaction" => %{
      "amount" => 41.12,
      "installments" => 2,
      "requested_at" => "2026-03-11T18:45:53Z"
    },
    "customer" => %{
      "avg_amount" => 82.24,
      "tx_count_24h" => 3,
      "known_merchants" => ["MERC-003", "MERC-016"]
    },
    "merchant" => %{
      "id" => "MERC-016",
      "mcc" => "5411",
      "avg_amount" => 60.25
    },
    "terminal" => %{
      "is_online" => false,
      "card_present" => true,
      "km_from_home" => 29.23
    },
    "last_transaction" => nil
  }

  # Exemplo FRAUDULENTO do DETECTION_RULES.md
  # Vetor esperado: [0.9506, 0.8333, 1.0, 0.2174, 0.8333, -1, -1, 0.9523, 1.0, 0, 1, 1, 0.75, 0.0055]
  @fraud_payload %{
    "id" => "tx-3330991687",
    "transaction" => %{
      "amount" => 9505.97,
      "installments" => 10,
      "requested_at" => "2026-03-14T05:15:12Z"
    },
    "customer" => %{
      "avg_amount" => 81.28,
      "tx_count_24h" => 20,
      "known_merchants" => ["MERC-008", "MERC-007", "MERC-005"]
    },
    "merchant" => %{
      "id" => "MERC-068",
      "mcc" => "7802",
      "avg_amount" => 54.86
    },
    "terminal" => %{
      "is_online" => false,
      "card_present" => true,
      "km_from_home" => 952.27
    },
    "last_transaction" => nil
  }

  test "vetoriza transação legítima corretamente" do
    vec = RinhaFraud.Vectorizer.vectorize(@legit_payload, @consts, @mcc_risk)

    assert length(vec) == 14

    # Compara com tolerância de 0.001
    expected = [0.0041, 0.1667, 0.05, 0.7826, 0.3333, -1.0, -1.0, 0.0292, 0.15, 0, 1, 0, 0.15, 0.006]
    Enum.zip(vec, expected)
    |> Enum.with_index()
    |> Enum.each(fn {{got, exp}, idx} ->
      assert_in_delta got, exp, 0.001,
        "Dimensão #{idx}: esperado #{exp}, obtido #{got}"
    end)
  end

  test "vetoriza transação fraudulenta corretamente" do
    vec = RinhaFraud.Vectorizer.vectorize(@fraud_payload, @consts, @mcc_risk)

    assert length(vec) == 14

    expected = [0.9506, 0.8333, 1.0, 0.2174, 0.8333, -1.0, -1.0, 0.9523, 1.0, 0, 1, 1, 0.75, 0.0055]
    Enum.zip(vec, expected)
    |> Enum.with_index()
    |> Enum.each(fn {{got, exp}, idx} ->
      assert_in_delta got, exp, 0.001,
        "Dimensão #{idx}: esperado #{exp}, obtido #{got}"
    end)
  end

  test "last_transaction nil retorna -1 nas dimensões 5 e 6" do
    vec = RinhaFraud.Vectorizer.vectorize(@legit_payload, @consts, @mcc_risk)
    assert Enum.at(vec, 5) == -1.0
    assert Enum.at(vec, 6) == -1.0
  end

  test "merchant desconhecido retorna 1 na dimensão 11" do
    payload = put_in(@legit_payload, ["merchant", "id"], "MERC-UNKNOWN")
    vec = RinhaFraud.Vectorizer.vectorize(payload, @consts, @mcc_risk)
    assert Enum.at(vec, 11) == 1
  end

  test "merchant conhecido retorna 0 na dimensão 11" do
    vec = RinhaFraud.Vectorizer.vectorize(@legit_payload, @consts, @mcc_risk)
    assert Enum.at(vec, 11) == 0
  end

  test "clamp mantém valores em [0, 1] exceto sentinelas -1" do
    vec = RinhaFraud.Vectorizer.vectorize(@fraud_payload, @consts, @mcc_risk)
    vec
    |> Enum.with_index()
    |> Enum.each(fn {v, idx} ->
      assert v == -1.0 or (v >= 0.0 and v <= 1.0),
        "Dimensão #{idx} fora do range: #{v}"
    end)
  end
end

defmodule RinhaFraud.LSHIndexTest do
  use ExUnit.Case

  setup do
    # Garante tabelas ETS limpas para cada teste
    [:lsh_projections, :lsh_buckets, :lsh_entries]
    |> Enum.each(fn t ->
      if :ets.whereis(t) != :undefined, do: :ets.delete_all_objects(t)
    end)
    :ok
  end

  test "encontra vizinho exato quando indexado" do
    # Indexa 10 vetores conhecidos
    entries = for i <- 1..10 do
      vec = for j <- 1..14, do: (i + j) / 100.0
      label = if rem(i, 2) == 0, do: :fraud, else: :legit
      %{id: "ref-#{i}", vector: vec, label: label}
    end

    RinhaFraud.LSHIndex.index_sync(entries)

    # Query igual ao primeiro vetor deve ter distância 0
    query = for j <- 1..14, do: (1 + j) / 100.0
    neighbors = RinhaFraud.LSHIndex.knn(query, 5)

    assert length(neighbors) > 0
    {dist, _label} = List.first(neighbors)
    assert dist < 0.001, "Distância ao vizinho mais próximo deveria ser ~0, foi #{dist}"
  end

  test "fraud_score calculado corretamente" do
    # 5 entradas: 3 fraud, 2 legit — todas próximas do query
    base = List.duplicate(0.5, 14)
    entries = [
      %{id: "f1", vector: perturb(base, 0.001), label: :fraud},
      %{id: "f2", vector: perturb(base, 0.002), label: :fraud},
      %{id: "f3", vector: perturb(base, 0.003), label: :fraud},
      %{id: "l1", vector: perturb(base, 0.004), label: :legit},
      %{id: "l2", vector: perturb(base, 0.005), label: :legit}
    ]

    RinhaFraud.LSHIndex.index_sync(entries)
    neighbors = RinhaFraud.LSHIndex.knn(base, 5)

    fraud_count = Enum.count(neighbors, fn {_, label} -> label == :fraud end)
    score = fraud_count / 5.0

    # Score >= 0.6 → deve negar
    assert score >= 0.6
  end

  defp perturb(vec, delta) do
    Enum.map(vec, fn v -> v + delta * :rand.uniform() end)
  end
end
