## ============================================================
## lib/rinha_fraud/application.ex
## ============================================================
defmodule RinhaFraud.Application do
  use Application
  require Logger

  @impl true
  def start(_type, _args) do
    children = [
      RinhaFraud.LSHIndex,
      {Bandit, plug: RinhaFraud.Router, port: 9999, startup_log: false}
    ]

    opts = [strategy: :one_for_one, name: RinhaFraud.Supervisor]
    {:ok, pid} = Supervisor.start_link(children, opts)

    # Carrega o índice ANTES de aceitar requests
    # (o Bandit já está no ar mas /ready retorna 503 até o índice estar pronto)
    Task.start(fn ->
      RinhaFraud.ReferencesLoader.load!()
      RinhaFraud.ReadyFlag.set_ready()
      Logger.info("[App] Índice pronto — aceitando requests")
    end)

    {:ok, pid}
  end
end

## ============================================================
## lib/rinha_fraud/ready_flag.ex
## ============================================================
defmodule RinhaFraud.ReadyFlag do
  use Agent

  def start_link(_), do: Agent.start_link(fn -> false end, name: __MODULE__)
  def ready?,        do: Agent.get(__MODULE__, & &1)
  def set_ready,     do: Agent.update(__MODULE__, fn _ -> true end)
end

## ============================================================
## lib/rinha_fraud/vectorizer.ex
## ============================================================
defmodule RinhaFraud.Vectorizer do
  @moduledoc """
  Transforma um payload de transação nos 14 vetores normalizados
  conforme especificado em DETECTION_RULES.md.
  """

  # Constantes de normalização (carregadas do normalization.json)
  # Defaults conforme spec
  @defaults %{
    "max_amount"              => 10_000,
    "max_installments"        => 12,
    "amount_vs_avg_ratio"     => 10,
    "max_minutes"             => 1_440,
    "max_km"                  => 1_000,
    "max_tx_count_24h"        => 20,
    "max_merchant_avg_amount" => 10_000
  }

  def load_consts(path \\ "/app/resources/normalization.json") do
    case File.read(path) do
      {:ok, raw} -> Map.merge(@defaults, Jason.decode!(raw))
      _          -> @defaults
    end
  end

  def load_mcc_risk(path \\ "/app/resources/mcc_risk.json") do
    case File.read(path) do
      {:ok, raw} -> Jason.decode!(raw)
      _          -> %{}
    end
  end

  @doc """
  Vetoriza um payload decodificado (map com chaves string).
  Retorna lista de 14 floats.
  """
  def vectorize(payload, consts, mcc_risk) do
    tx       = payload["transaction"]
    customer = payload["customer"]
    merchant = payload["merchant"]
    terminal = payload["terminal"]
    last_tx  = payload["last_transaction"]

    # Parse da data uma vez só
    {:ok, requested_at, _} = DateTime.from_iso8601(tx["requested_at"])
    hour = requested_at.hour
    # day_of_week: mon=0, sun=6
    dow = Date.day_of_week(DateTime.to_date(requested_at)) - 1

    [
      # 0 — amount
      clamp(tx["amount"] / consts["max_amount"]),
      # 1 — installments
      clamp(tx["installments"] / consts["max_installments"]),
      # 2 — amount_vs_avg
      clamp((tx["amount"] / safe_avg(customer["avg_amount"])) / consts["amount_vs_avg_ratio"]),
      # 3 — hour_of_day
      hour / 23.0,
      # 4 — day_of_week
      dow / 6.0,
      # 5 — minutes_since_last_tx
      minutes_since_last(last_tx, consts["max_minutes"]),
      # 6 — km_from_last_tx
      km_from_last(last_tx, consts["max_km"]),
      # 7 — km_from_home
      clamp(terminal["km_from_home"] / consts["max_km"]),
      # 8 — tx_count_24h
      clamp(customer["tx_count_24h"] / consts["max_tx_count_24h"]),
      # 9 — is_online
      bool_int(terminal["is_online"]),
      # 10 — card_present
      bool_int(terminal["card_present"]),
      # 11 — unknown_merchant (1 = desconhecido)
      unknown_merchant(merchant["id"], customer["known_merchants"]),
      # 12 — mcc_risk
      Map.get(mcc_risk, merchant["mcc"], 0.5),
      # 13 — merchant_avg_amount
      clamp(merchant["avg_amount"] / consts["max_merchant_avg_amount"])
    ]
  end

  # -------------------------
  # Helpers
  # -------------------------

  defp clamp(x) when x < 0.0, do: 0.0
  defp clamp(x) when x > 1.0, do: 1.0
  defp clamp(x),               do: x * 1.0

  defp bool_int(true),  do: 1
  defp bool_int(false), do: 0
  defp bool_int(1),     do: 1
  defp bool_int(_),     do: 0

  defp safe_avg(nil), do: 1.0
  defp safe_avg(0.0), do: 1.0
  defp safe_avg(0),   do: 1.0
  defp safe_avg(v),   do: v

  defp unknown_merchant(merchant_id, known) when is_list(known) do
    if merchant_id in known, do: 0, else: 1
  end
  defp unknown_merchant(_, _), do: 1

  defp minutes_since_last(nil, _max), do: -1.0
  defp minutes_since_last(last_tx, max_minutes) do
    case DateTime.from_iso8601(last_tx["timestamp"]) do
      {:ok, last_dt, _} ->
        # timestamp do last_tx é o horário da transação anterior
        # mas não temos o "now" — usamos o campo diretamente se disponível
        # A spec não deixa explícito; usamos km_from_current como proxy
        # Na prática, minutes_since precisa vir no payload ou ser calculado
        # Verificar API.md para o campo exato
        minutes = Map.get(last_tx, "minutes_ago", 0)
        clamp(minutes / max_minutes)
      _ ->
        clamp(Map.get(last_tx, "minutes_ago", 0) / max_minutes)
    end
  end

  defp km_from_last(nil, _max), do: -1.0
  defp km_from_last(last_tx, max_km) do
    clamp(last_tx["km_from_current"] / max_km)
  end
end

## ============================================================
## lib/rinha_fraud/router.ex
## ============================================================
defmodule RinhaFraud.Router do
  use Plug.Router

  plug Plug.Parsers,
    parsers: [:json],
    json_decoder: Jason

  plug :match
  plug :dispatch

  # Carregados uma vez no startup do módulo (imutáveis durante o processo)
  @consts   RinhaFraud.Vectorizer.load_consts()
  @mcc_risk RinhaFraud.Vectorizer.load_mcc_risk()

  get "/ready" do
    if RinhaFraud.ReadyFlag.ready?() do
      send_resp(conn, 200, "ok")
    else
      send_resp(conn, 503, "loading")
    end
  end

  post "/fraud-score" do
    payload = conn.body_params

    vec = RinhaFraud.Vectorizer.vectorize(payload, @consts, @mcc_risk)
    neighbors = RinhaFraud.LSHIndex.knn(vec, 5)

    fraud_count = Enum.count(neighbors, fn {_dist, label} -> label == :fraud end)
    fraud_score = fraud_count / 5.0
    approved    = fraud_score < 0.6

    response = Jason.encode!(%{approved: approved, fraud_score: fraud_score})
    conn
    |> put_resp_content_type("application/json")
    |> send_resp(200, response)
  end

  match _ do
    send_resp(conn, 404, "not found")
  end
end
