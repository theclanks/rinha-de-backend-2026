defmodule RinhaFraud.ReferencesLoader do
  @moduledoc """
  Carrega references.json.gz no startup e alimenta o LSHIndex.

  O arquivo tem formato NDJSON (uma entrada por linha):
    {"id":"ref-001","vector":[0.12,0.33,...],"label":"fraud"}
    {"id":"ref-002","vector":[0.05,0.11,...],"label":"legit"}
    ...

  Estratégia: streaming em chunks para não explodir a memória
  durante o parse — importante dado o limite de 350MB total.
  """

  require Logger

  @chunk_size 5_000  # entradas por batch de indexação

  def load!(path \\ "/app/resources/references.json.gz") do
    Logger.info("[ReferencesLoader] Iniciando carga de #{path}")
    t0 = System.monotonic_time(:millisecond)

    path
    |> stream_gz_lines()
    |> Stream.map(&parse_line/1)
    |> Stream.reject(&is_nil/1)
    |> Stream.chunk_every(@chunk_size)
    |> Stream.each(fn chunk ->
      RinhaFraud.LSHIndex.index_sync(chunk)
      Logger.debug("[ReferencesLoader] Chunk de #{length(chunk)} indexado")
    end)
    |> Stream.run()

    elapsed = System.monotonic_time(:millisecond) - t0
    total = RinhaFraud.LSHIndex.size()
    Logger.info("[ReferencesLoader] #{total} entradas indexadas em #{elapsed}ms")

    :ok
  end

  # -------------------------
  # Streaming do .gz
  # -------------------------

  defp stream_gz_lines(path) do
    # Abre o arquivo gz e faz stream linha a linha
    # usando :zlib para descompressão incremental
    Stream.resource(
      fn -> open_gz(path) end,
      fn {gz, buf} -> read_lines(gz, buf) end,
      fn {gz, _buf} -> :zlib.close(gz) end
    )
  end

  defp open_gz(path) do
    gz = :zlib.open()
    :ok = :zlib.inflateInit(gz, 31)  # 31 = gzip header
    fd = File.open!(path, [:read, :binary])
    {gz, fd, ""}
  end

  # Versão simplificada usando File.stream! com descompressão nativa do Elixir
  # (mais simples e igualmente eficiente para este caso)
  defp stream_gz_lines_simple(path) do
    # Elixir/Erlang suporta :compressed diretamente
    # Mas references.json.gz é gzip, não erlang term —
    # usamos :zlib manualmente ou lemos tudo e descomprimimos
    raw = File.read!(path)
    decompressed = :zlib.gunzip(raw)

    decompressed
    |> String.split("\n", trim: true)
  end

  # Re-implementa stream_gz_lines de forma mais simples e robusta
  defp stream_gz_lines(path) do
    # Para 100k entradas o arquivo descomprimido fica ~50MB — ok para ler tudo
    raw = File.read!(path)
    decompressed = :zlib.gunzip(raw)

    decompressed
    |> String.split("\n", trim: true)
  end

  # -------------------------
  # Parse de linha NDJSON
  # -------------------------

  defp parse_line(line) when byte_size(line) < 5, do: nil
  defp parse_line(line) do
    case Jason.decode(line) do
      {:ok, %{"id" => id, "vector" => vec, "label" => label_str}} ->
        %{
          id: id,
          vector: vec,
          label: parse_label(label_str)
        }
      _ ->
        nil
    end
  end

  defp parse_label("fraud"), do: :fraud
  defp parse_label(_),       do: :legit
end
